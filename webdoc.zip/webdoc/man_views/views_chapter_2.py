# views_chapter_2.py
from django.shortcuts import render
from django.http import JsonResponse, FileResponse
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db import IntegrityError
from django.conf import settings
from django.core.files.storage import default_storage
from io import BytesIO

import json
import traceback

from backend.models import DocChapter2
from man_doc.doc_chapter2 import generate_doc


@login_required
def chapter_2_view(request):
    user = request.user

    if request.method == 'POST':
        action = (request.POST.get('action') or '').strip()

        # ---------- get_data ----------
        if action == 'get_data':
            row = DocChapter2.objects.filter(user=user).first()
            initial_sections = []

            if row:
                # ป้องกันกรณี sections_json เป็น string
                sections = row.sections_json
                try:
                    if isinstance(sections, str):
                        sections = json.loads(sections)
                except json.JSONDecodeError:
                    sections = []
                initial_sections = sections

            return JsonResponse({
                'initial': {
                    'intro_body': (row.intro_body if row else "") or "",
                    'sections': initial_sections,
                }
            })

        # ---------- save ----------
        if action == 'save':
            intro_body = request.POST.get('intro_body', '')

            raw_sections = request.POST.get('sections_json', '[]')
            try:
                sections_data = json.loads(raw_sections)
                if not isinstance(sections_data, list):
                    sections_data = []
            except json.JSONDecodeError:
                sections_data = []

            try:
                DocChapter2.objects.update_or_create(
                    user=request.user,
                    defaults={
                        'chap_id': 2,
                        'intro_body': intro_body,
                        'sections_json': sections_data,
                        'updated_at': timezone.now(),
                    }
                )
            except IntegrityError as e:
                return JsonResponse({'status': 'error', 'message': f'IntegrityError: {e}'}, status=400)
            except Exception as e:
                return JsonResponse({'status': 'error', 'message': f'Error: {e}'}, status=400)

            return JsonResponse({'status': 'ok'})
   
        # ---------- generate_doc ----------
        if action == "generate_doc":
            # ดึงข้อมูล
            row = DocChapter2.objects.filter(user=user).first()
            intro = row.intro_body if row else ""
            sections = row.sections_json if row else []

            # sections_json อาจเป็น string
            try:
                if isinstance(sections, str):
                    sections = json.loads(sections)
            except json.JSONDecodeError:
                sections = []

            # helper: ดึงรูปจากโครงสร้าง sections
            def extractAllPictures(sections_list):
                pics = []
                def walkNode(node):
                    if not isinstance(node, dict): return
                    if isinstance(node.get("pictures"), list):
                        pics.extend([p for p in node["pictures"] if p])
                    if isinstance(node.get("children"), list):
                        for ch in node["children"]:
                            walkNode(ch)
                if isinstance(sections_list, list):
                    for sec in sections_list:
                        if not isinstance(sec, dict): continue
                        if isinstance(sec.get("pictures"), list):
                            pics.extend([p for p in sec["pictures"] if p])
                        if isinstance(sec.get("items"), list):
                            for node in sec["items"]:
                                walkNode(node)
                def seq(p):
                    try:
                        return int(str(p.get("pic_no","0-0")).split("-")[-1])
                    except Exception:
                        return 0
                pics.sort(key=seq)
                return pics

            all_pics = extractAllPictures(sections)

            # สร้างเอกสารในหน่วยความจำ
            doc = generate_doc(
                intro_body=intro,
                sections_json=sections,
                pictures=all_pics,
                media_root=settings.MEDIA_ROOT,
            )
            from io import BytesIO
            bio = BytesIO()
            doc.save(bio)
            bio.seek(0)

            # ส่งกลับเป็นไฟล์ดาวน์โหลดทันที (ไม่เซฟเซิร์ฟเวอร์)
            resp = FileResponse(
                bio,
                as_attachment=True,
                filename="chapter2.docx",
                content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            )
            # กัน cache ถ้าต้องการ
            resp["Cache-Control"] = "no-store"
            return resp

    
        # ---------- add_picture ----------
        if action == 'add_picture':
            try:
                pic_name = request.POST.get('pic_name', '').strip()
                client_pic_no = request.POST.get('pic_no', '').strip()
                upfile = request.FILES.get('pic_file')

                if not upfile:
                    return JsonResponse({'status': 'error', 'message': 'ไม่พบไฟล์ (pic_file)'}, status=400)

                user_specific_path = f'img/user_{request.user.username}/{upfile.name}'
                saved_relative_path = default_storage.save(user_specific_path, upfile)
                saved_url = default_storage.url(saved_relative_path)

                picture_block = {
                    "pic_no": client_pic_no,
                    "pic_name": pic_name,
                    "pic_path": saved_relative_path,
                    "pic_url": saved_url
                }
                return JsonResponse({"status": "ok", "message": "อัปโหลดรูปสำเร็จ", "picture": picture_block})
            except Exception:
                return JsonResponse(
                    {'status': 'error', 'message': 'Upload failed', 'trace': traceback.format_exc()},
                    status=500
                )

        # unknown action
        return JsonResponse({'status': 'error', 'message': f'unknown action "{action}"'}, status=400)

    # GET
    return render(request, "chapter_2.html", {
        "page_title": "บทที่ 2 เอกสารและงานวิจัยที่เกี่ยวข้อง"
    })
